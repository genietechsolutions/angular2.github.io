import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-myform-cmp',
  templateUrl: './myform-cmp.component.html',
  styleUrls: ['./myform-cmp.component.css']
})
export class MyformCmpComponent implements OnInit {

  constructor() { }
  name="venkat"
validate(a,b){	
	alert("working"+a+b)
}
  ngOnInit() {
  }

}
