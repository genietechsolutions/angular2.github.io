import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-cmp',
  templateUrl: './header-cmp.component.html',
  styleUrls: ['./header-cmp.component.css']
})
export class HeaderCmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
