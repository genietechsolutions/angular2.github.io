import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-cmp',
  templateUrl: './home-cmp.component.html',
  styleUrls: ['./home-cmp.component.css']
})
export class HomeCmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
