import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-route-cmp',
  templateUrl: './my-route-cmp.component.html',
  styleUrls: ['./my-route-cmp.component.css']
})
export class MyRouteCmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
