import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipesexamples',
  templateUrl: './pipesexamples.component.html',
  styleUrls: ['./pipesexamples.component.css']
})
export class PipesexamplesComponent {

 public name='Bhavani is a good girl';
  xyz='HI WELCOME TO GENIE';
  a: number = 0.259;
  b: number = 1.3495;
  today=Date.now();
  birthday=Date.now();
 

}
