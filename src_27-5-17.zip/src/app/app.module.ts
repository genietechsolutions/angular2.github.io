import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AlertModule,DatepickerModule } from 'ngx-bootstrap';


import { AppComponent } from './app.component';
import { HomeCmpComponent } from './home-cmp/home-cmp.component';
import { MyformCmpComponent } from './myform-cmp/myform-cmp.component';
import { HeaderCmpComponent } from './header-cmp/header-cmp.component';
import { FooterCmpComponent } from './footer-cmp/footer-cmp.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeCmpComponent,
    MyformCmpComponent,
    HeaderCmpComponent,
    FooterCmpComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
	AlertModule,
	DatepickerModule
  ],
  providers: [],
  bootstrap: [MyformCmpComponent]
})
export class AppModule { }
